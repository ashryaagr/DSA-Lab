#include<stdio.h>

int getmem();
void * myalloc(int num);
void myfree(void * ptr);
void playarray(int M);
void q2();
