#include<stdio.h>
#include "linkedlist.h"

struct linkedList createList(int N);
struct linkedList createCycle( struct linkedList Ls);
