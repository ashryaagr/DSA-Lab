#include<stdio.h>
#include "q3.h"

int testCycle(struct linkedList L);
